using BlazorShared.Attributes;

namespace BlazorShared.Models;

[Endpoint(Name = "catalog-types")]
public class CatalogType : LookupData
{
}
