namespace Microsoft.eShopWeb.Web.ViewModels;

public class BasketComponentViewModel
{
    public int ItemsCount { get; set; }
}
